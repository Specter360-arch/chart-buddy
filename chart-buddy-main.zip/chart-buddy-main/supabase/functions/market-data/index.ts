/// <reference types="https://deno.land/x/deno/cli/types/deno.d.ts" />

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// AllTick API Interfaces (adjust based on actual API response)
interface AllTickQuote {
  symbol: string;
  name?: string;
  price: number;
  change: number;
  change_percent: number;
  day_high: number;
  day_low: number;
  volume: number;
  previous_close: number;
}

interface AllTickTimeSeries {
  symbol: string;
  interval: string;
  candles: Array<{
    timestamp: number; // Unix timestamp (seconds)
    open: number;
    high: number;
    low: number;
    close: number;
    volume?: number;
  }>;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('ALLTICK_API_KEY');
    if (!apiKey) {
      console.error('ALLTICK_API_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'AllTick API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { action, symbol, interval, outputsize } = await req.json();
    console.log(`Market data request: action=${action}, symbol=${symbol}, interval=${interval}`);

    const baseUrl = 'https://api.alltick.io/v1';

    if (action === 'quote') {
      const response = await fetch(
        `${baseUrl}/quote?symbol=${encodeURIComponent(symbol)}&apiKey=${apiKey}`
      );
      const data = await response.json();

      if (!response.ok || data.status === 'error') {
        console.error('AllTick quote error:', data);
        return new Response(
          JSON.stringify({ success: false, error: data.message || 'Failed to fetch quote' }),
          { status: response.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      // Adapt AllTick response to the format expected by the client
      const quoteData: AllTickQuote = data.data;
      const formattedQuote = {
        symbol: quoteData.symbol,
        name: quoteData.name || symbol,
        close: quoteData.price,
        change: quoteData.change,
        percent_change: quoteData.change_percent,
        high: quoteData.day_high,
        low: quoteData.day_low,
        volume: quoteData.volume,
        previous_close: quoteData.previous_close,
      };

      console.log(`Quote fetched for ${symbol}`);
      return new Response(
        JSON.stringify({ success: true, data: formattedQuote }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'time_series') {
      const size = outputsize || 100;
      const timeInterval = interval || '1D';

      const response = await fetch(
        `${baseUrl}/history?symbol=${encodeURIComponent(symbol)}&interval=${timeInterval}&limit=${size}&apiKey=${apiKey}`
      );
      const data: AllTickTimeSeries = await response.json();

      if (!response.ok || (data as any).status === 'error') {
        console.error('AllTick time_series error:', data);
        return new Response(
          JSON.stringify({ success: false, error: (data as any).message || 'Failed to fetch time series' }),
          { status: response.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // AllTick should return timestamps and chronological data, so less transformation is needed
      const candleData = data.candles?.map((c) => ({
        time: c.timestamp, // Assuming AllTick provides Unix timestamp
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
        volume: c.volume || 0,
      }));

      console.log(`Time series fetched for ${symbol}: ${candleData?.length || 0} candles`);
      return new Response(
        JSON.stringify({ 
          success: true, 
          data: candleData,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'batch_quote') {
      const symbols = Array.isArray(symbol) ? symbol.join(',') : symbol;
      
      const response = await fetch(
        `${baseUrl}/quote/batch?symbols=${encodeURIComponent(symbols)}&apiKey=${apiKey}`
      );
      const data = await response.json();

      if (!response.ok || data.status === 'error') {
        console.error('AllTick batch quote error:', data);
        return new Response(
          JSON.stringify({ success: false, error: data.message || 'Failed to fetch batch quotes' }),
          { status: response.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Adapt the batch response
      const formattedBatch = Object.entries(data.data).reduce((acc, [key, quote]: [string, any]) => {
        acc[key] = {
          symbol: quote.symbol,
          name: quote.name || key,
          close: quote.price,
          change: quote.change,
          percent_change: quote.change_percent,
          high: quote.day_high,
          low: quote.day_low,
          volume: quote.volume,
          previous_close: quote.previous_close,
        };
        return acc;
      }, {} as Record<string, any>);

      console.log(`Batch quote fetched for ${symbols}`);
      return new Response(
        JSON.stringify({ success: true, data: formattedBatch }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Invalid action. Use: quote, time_series, or batch_quote' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Market data error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Failed to fetch market data';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

export {};
