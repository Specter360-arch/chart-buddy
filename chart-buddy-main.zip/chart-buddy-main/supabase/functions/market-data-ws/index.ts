/// <reference types="https://deno.land/x/deno/cli/types/deno.d.ts" />

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// AllTick WebSocket integration
Deno.serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.headers.get('upgrade')?.toLowerCase() !== 'websocket') {
    return new Response('Expected WebSocket connection', {
      status: 400,
      headers: corsHeaders,
    });
  }

  const { socket: clientSocket, response } = Deno.upgradeWebSocket(req);
  const apiKey = Deno.env.get('ALLTICK_API_KEY');

  if (!apiKey) {
    console.error('ALLTICK_API_KEY not configured');
    clientSocket.onopen = () => {
      clientSocket.send(JSON.stringify({
        type: 'error',
        message: 'AllTick API key not configured on the server.',
      }));
      clientSocket.close(1011, 'API key not configured');
    };
    return response;
  }

  let allTickSocket: WebSocket | null = null;

  clientSocket.onopen = () => {
    console.log('Client WebSocket connection established.');

    // Establish connection to AllTick WebSocket API
    const allTickUrl = `wss://api.alltick.io/v1/stream?apiKey=${apiKey}`;
    allTickSocket = new WebSocket(allTickUrl);

    allTickSocket.onopen = () => {
      console.log('Connected to AllTick WebSocket API.');
      clientSocket.send(JSON.stringify({
        type: 'connected',
        message: 'Successfully connected to real-time data stream.',
      }));

      // Subscribe to the requested symbols
      const symbols = ["Gold/XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "AUDUSD"];
      const subscriptionMessage = JSON.stringify({
        action: 'subscribe',
        symbols: symbols,
      });
      if (allTickSocket) {
        allTickSocket.send(subscriptionMessage);
      }
      console.log(`Subscribed to symbols: ${symbols.join(', ')}`);
    };

    allTickSocket.onmessage = (event: MessageEvent) => {
      // Forward messages from AllTick to the client
      try {
        const message = JSON.parse(event.data);
        clientSocket.send(JSON.stringify(message));
      } catch (error) {
        console.error('Failed to parse or forward message from AllTick:', error);
      }
    };

    allTickSocket.onerror = (error: Event) => {
      console.error('AllTick WebSocket error:', error);
      clientSocket.send(JSON.stringify({
        type: 'error',
        message: 'Error with the real-time data stream.',
      }));
    };

    allTickSocket.onclose = (event: CloseEvent) => {
      console.log(`AllTick WebSocket closed: ${event.code} ${event.reason}`);
      if (clientSocket.readyState === WebSocket.OPEN) {
        clientSocket.close(1001, 'Upstream connection closed');
      }
    };
  };

  clientSocket.onmessage = (event: MessageEvent) => {
    // Handle messages from the client, e.g., for dynamic subscriptions
    console.log('Received message from client:', event.data);
    // For now, we just log it. Could be extended to change subscriptions.
  };

  clientSocket.onclose = () => {
    console.log('Client WebSocket connection closed.');
    if (allTickSocket && allTickSocket.readyState === WebSocket.OPEN) {
      allTickSocket.close();
    }
  };

  clientSocket.onerror = (error: Event) => {
    console.error('Client WebSocket error:', error);
    if (allTickSocket && allTickSocket.readyState === WebSocket.OPEN) {
      allTickSocket.close();
    }
  };

  return response;
});

export {};
