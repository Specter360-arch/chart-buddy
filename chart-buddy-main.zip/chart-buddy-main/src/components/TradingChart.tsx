import { useEffect, useRef } from "react";
import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickData,
  Time,
  CandlestickSeries,
  LineSeries,
  HistogramSeries,
  CrosshairMode,
  PriceLineOptions,
} from "lightweight-charts";

interface TradingChartProps {
  data: CandlestickData<Time>[];
  volumeData?: { time: Time; value: number; color?: string }[];
  chartType?: "candlestick" | "line";
  showVolume?: boolean;
  rsiData?: { time: Time; value: number }[];
  macdData?: {
    macd: { time: Time; value: number }[];
    signal: { time: Time; value: number }[];
    histogram: { time: Time; value: number; color: string }[];
  };
  bollingerData?: {
    upper: { time: Time; value: number }[];
    middle: { time: Time; value: number }[];
    lower: { time: Time; value: number }[];
  };
}

export const TradingChart = ({ 
  data, 
  volumeData, 
  chartType = "candlestick",
  showVolume = false,
  rsiData,
  macdData,
  bollingerData
}: TradingChartProps) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRefs = useRef<Map<string, ISeriesApi<any>>>(new Map());
  const mainSeriesTypeRef = useRef<"candlestick" | "line" | null>(null);
  const priceLineRef = useRef<{ remove: () => void } | null>(null);
  const hasFittedOnceRef = useRef(false);

  useEffect(() => {
    if (!chartContainerRef.current) return;

    const getResponsiveHeight = () => {
      if (window.innerWidth < 640) return 500;
      if (window.innerWidth < 1024) return 600;
      return 700;
    };

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: getResponsiveHeight(),
      layout: {
        background: { color: "hsl(220, 20%, 10%)" },
        textColor: "hsl(210, 40%, 98%)",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
        fontSize: 12,
      },
      watermark: {
        visible: true,
        color: "rgba(255,255,255,0.04)",
        text: "Chart Buddy",
        fontSize: 16,
      },
      grid: {
        vertLines: { color: "hsl(220, 18%, 16%)", style: 1 },
        horzLines: { color: "hsl(220, 18%, 16%)", style: 1 },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: "hsl(180, 85%, 55%)",
          width: 1,
          style: 2,
          labelBackgroundColor: "hsl(180, 85%, 35%)",
        },
        horzLine: {
          color: "hsl(180, 85%, 55%)",
          width: 1,
          style: 2,
          labelBackgroundColor: "hsl(180, 85%, 35%)",
        },
      },
      rightPriceScale: {
        borderColor: "hsl(220, 18%, 20%)",
        scaleMargins: { top: 0.08, bottom: 0.18 },
        autoScale: true,
      },
      timeScale: {
        borderColor: "hsl(220, 18%, 20%)",
        timeVisible: true,
        secondsVisible: false,
        barSpacing: 12,
        minBarSpacing: 6,
        rightOffset: 6,
        shiftVisibleRangeOnNewBar: true,
      },
      handleScale: {
        axisPressedMouseMove: { time: true, price: true },
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: true,
      },
    });

    chartRef.current = chart;
    seriesRefs.current.clear();
    hasFittedOnceRef.current = false;

    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: getResponsiveHeight(),
        });
      }
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      priceLineRef.current = null;
      mainSeriesTypeRef.current = null;
      chart.remove();
    };
  }, []);

  useEffect(() => {
    const chart = chartRef.current;
    if (!chart || data.length === 0) return;

    const setPriceLine = (series: ISeriesApi<any>, price: number) => {
      if (priceLineRef.current) priceLineRef.current.remove();
      const opts: PriceLineOptions = {
        price,
        color: "#22c55e",
        lineWidth: 2,
        lineStyle: 0,
        axisLabelVisible: true,
        title: "Last",
      };
      priceLineRef.current = series.createPriceLine(opts);
    };

    // Main series
    let main = seriesRefs.current.get("main");
    if (main && mainSeriesTypeRef.current !== chartType) {
      chart.removeSeries(main);
      seriesRefs.current.delete("main");
      main = undefined;
    }
    if (!main) {
      if (chartType === "candlestick") {
        main = chart.addSeries(CandlestickSeries, {
          upColor: "#22c55e",
          downColor: "#ef4444",
          borderVisible: true,
          borderUpColor: "#16a34a",
          borderDownColor: "#dc2626",
          wickUpColor: "#22c55e",
          wickDownColor: "#ef4444",
          priceLineVisible: false,
          lastValueVisible: false,
        });
        main.priceScale().applyOptions({ scaleMargins: { top: 0.05, bottom: 0.15 } });
        mainSeriesTypeRef.current = "candlestick";
      } else {
        main = chart.addSeries(LineSeries, {
          color: "hsl(180, 85%, 55%)",
          lineWidth: 2,
          crosshairMarkerVisible: true,
          crosshairMarkerRadius: 4,
          priceLineVisible: false,
          lastValueVisible: false,
        });
        main.priceScale().applyOptions({ scaleMargins: { top: 0.05, bottom: 0.15 } });
        mainSeriesTypeRef.current = "line";
      }
      seriesRefs.current.set("main", main);
    }
    if (mainSeriesTypeRef.current === "candlestick") {
      main.setData(data);
    } else {
      main.setData(data.map((d) => ({ time: d.time, value: d.close })));
    }
    const last = data[data.length - 1];
    if (last?.close) setPriceLine(main, last.close);

    // Bollinger
    const bollingerKeys = ["bollinger-upper", "bollinger-middle", "bollinger-lower"] as const;
    if (!bollingerData) {
      bollingerKeys.forEach((k) => {
        const s = seriesRefs.current.get(k);
        if (s) {
          chart.removeSeries(s);
          seriesRefs.current.delete(k);
        }
      });
    } else {
      const up = seriesRefs.current.get("bollinger-upper") ?? chart.addSeries(LineSeries, { color: "hsl(180, 85%, 55%)", lineWidth: 1, lineStyle: 2 });
      up.setData(bollingerData.upper.filter((d) => !isNaN(d.value)));
      seriesRefs.current.set("bollinger-upper", up);

      const mid = seriesRefs.current.get("bollinger-middle") ?? chart.addSeries(LineSeries, { color: "hsl(180, 85%, 55%)", lineWidth: 1 });
      mid.setData(bollingerData.middle.filter((d) => !isNaN(d.value)));
      seriesRefs.current.set("bollinger-middle", mid);

      const low = seriesRefs.current.get("bollinger-lower") ?? chart.addSeries(LineSeries, { color: "hsl(180, 85%, 55%)", lineWidth: 1, lineStyle: 2 });
      low.setData(bollingerData.lower.filter((d) => !isNaN(d.value)));
      seriesRefs.current.set("bollinger-lower", low);
    }

    // Volume
    if (!showVolume || !volumeData || volumeData.length === 0) {
      const vol = seriesRefs.current.get("volume");
      if (vol) {
        chart.removeSeries(vol);
        seriesRefs.current.delete("volume");
      }
    } else {
      let vol = seriesRefs.current.get("volume");
      if (!vol) {
        vol = chart.addSeries(HistogramSeries, {
          color: "hsl(180, 85%, 55%)",
          priceFormat: { type: "volume" },
          priceScaleId: "",
        });
        vol.priceScale().applyOptions({ scaleMargins: { top: 0.8, bottom: 0 } });
        seriesRefs.current.set("volume", vol);
      }
      vol.setData(volumeData);
    }

    // RSI
    if (!rsiData) {
      const rsi = seriesRefs.current.get("rsi");
      if (rsi) {
        chart.removeSeries(rsi);
        seriesRefs.current.delete("rsi");
      }
    } else {
      let rsi = seriesRefs.current.get("rsi");
      if (!rsi) {
        rsi = chart.addSeries(LineSeries, {
          color: "hsl(270, 70%, 60%)",
          lineWidth: 2,
          priceScaleId: "rsi",
        });
        rsi.priceScale().applyOptions({ scaleMargins: { top: 0.85, bottom: 0 } });
        seriesRefs.current.set("rsi", rsi);
      }
      rsi.setData(rsiData.filter((d) => !isNaN(d.value)));
    }

    // MACD
    const macdKeys = ["macd", "macd-signal", "macd-histogram"] as const;
    if (!macdData) {
      macdKeys.forEach((k) => {
        const s = seriesRefs.current.get(k);
        if (s) {
          chart.removeSeries(s);
          seriesRefs.current.delete(k);
        }
      });
    } else {
      let macd = seriesRefs.current.get("macd");
      if (!macd) {
        macd = chart.addSeries(LineSeries, { color: "hsl(200, 70%, 60%)", lineWidth: 2, priceScaleId: "macd" });
        macd.priceScale().applyOptions({ scaleMargins: { top: 0.9, bottom: 0 } });
        seriesRefs.current.set("macd", macd);
      }
      macd.setData(macdData.macd.filter((d) => !isNaN(d.value)));

      let macdSignal = seriesRefs.current.get("macd-signal");
      if (!macdSignal) {
        macdSignal = chart.addSeries(LineSeries, { color: "hsl(30, 70%, 60%)", lineWidth: 2, priceScaleId: "macd" });
        seriesRefs.current.set("macd-signal", macdSignal);
      }
      macdSignal.setData(macdData.signal.filter((d) => !isNaN(d.value)));

      let macdHist = seriesRefs.current.get("macd-histogram");
      if (!macdHist) {
        macdHist = chart.addSeries(HistogramSeries, { priceScaleId: "macd" });
        seriesRefs.current.set("macd-histogram", macdHist);
      }
      macdHist.setData(macdData.histogram.filter((d) => !isNaN(d.value)));
    }

    if (!hasFittedOnceRef.current) {
      chart.timeScale().fitContent();
      hasFittedOnceRef.current = true;
    }
  }, [chartType, data, volumeData, showVolume, rsiData, macdData, bollingerData]);

  return <div ref={chartContainerRef} className="w-full" />;
};
