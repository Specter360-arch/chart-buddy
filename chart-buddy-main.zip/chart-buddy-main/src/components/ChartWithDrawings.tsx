import { useEffect, useRef, useCallback, useState } from "react";
import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickData,
  Time,
  CandlestickSeries,
  LineSeries,
  HistogramSeries,
  MouseEventParams,
  CrosshairMode,
  SeriesOptionsMap,
  PriceLineOptions,
} from "lightweight-charts";
import { Drawing, DrawingPoint, DrawingType } from "@/hooks/useChartDrawings";

interface ChartWithDrawingsProps {
  data: CandlestickData<Time>[];
  volumeData?: { time: Time; value: number; color?: string }[];
  chartType?: "candlestick" | "line";
  showVolume?: boolean;
  rsiData?: { time: Time; value: number }[];
  macdData?: {
    macd: { time: Time; value: number }[];
    signal: { time: Time; value: number }[];
    histogram: { time: Time; value: number; color: string }[];
  };
  bollingerData?: {
    upper: { time: Time; value: number }[];
    middle: { time: Time; value: number }[];
    lower: { time: Time; value: number }[];
  };
  // Drawing props
  drawings: Drawing[];
  currentDrawing: Partial<Drawing> | null;
  activeDrawingTool: DrawingType | null;
  isDrawing: boolean;
  onDrawingStart: (point: DrawingPoint) => void;
  onDrawingUpdate: (point: DrawingPoint) => void;
  onDrawingEnd: () => void;
  onDrawingSelect?: (id: string | null) => void;
  selectedDrawingId?: string | null;
  fullscreen?: boolean;
}

export const ChartWithDrawings = ({
  data,
  volumeData,
  chartType = "candlestick",
  showVolume = false,
  rsiData,
  macdData,
  bollingerData,
  drawings,
  currentDrawing,
  activeDrawingTool,
  isDrawing,
  onDrawingStart,
  onDrawingUpdate,
  onDrawingEnd,
  onDrawingSelect,
  selectedDrawingId,
  fullscreen = false,
}: ChartWithDrawingsProps) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const mainSeriesRef = useRef<ISeriesApi<any> | null>(null);
  const mainSeriesTypeRef = useRef<"candlestick" | "line" | null>(null);
  const priceLineRef = useRef<{ remove: () => void } | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<any> | null>(null);
  const rsiSeriesRef = useRef<ISeriesApi<any> | null>(null);
  const macdSeriesRef = useRef<{
    macd?: ISeriesApi<any>;
    signal?: ISeriesApi<any>;
    histogram?: ISeriesApi<any>;
  }>({ macd: undefined, signal: undefined, histogram: undefined });
  const bollingerSeriesRef = useRef<{
    upper?: ISeriesApi<any>;
    middle?: ISeriesApi<any>;
    lower?: ISeriesApi<any>;
  }>({ upper: undefined, middle: undefined, lower: undefined });
  const hasFittedOnceRef = useRef(false);
  
  // Use refs to avoid stale closures in event handlers
  const activeDrawingToolRef = useRef(activeDrawingTool);
  const isDrawingRef = useRef(isDrawing);
  const onDrawingStartRef = useRef(onDrawingStart);
  const onDrawingUpdateRef = useRef(onDrawingUpdate);
  const onDrawingEndRef = useRef(onDrawingEnd);
  const onDrawingSelectRef = useRef(onDrawingSelect);

  // Keep refs updated
  useEffect(() => {
    activeDrawingToolRef.current = activeDrawingTool;
  }, [activeDrawingTool]);

  useEffect(() => {
    isDrawingRef.current = isDrawing;
  }, [isDrawing]);

  useEffect(() => {
    onDrawingStartRef.current = onDrawingStart;
    onDrawingUpdateRef.current = onDrawingUpdate;
    onDrawingEndRef.current = onDrawingEnd;
    onDrawingSelectRef.current = onDrawingSelect;
  }, [onDrawingStart, onDrawingUpdate, onDrawingEnd, onDrawingSelect]);

  // Get chart coordinates from mouse event
  const getChartPoint = useCallback(
    (param: MouseEventParams): DrawingPoint | null => {
      if (!param.time || !param.point || !mainSeriesRef.current) return null;
      
      const price = mainSeriesRef.current.coordinateToPrice(param.point.y);
      if (price === null) return null;
      
      return {
        time: param.time as Time,
        price,
      };
    },
    []
  );

  // Draw all drawings on canvas overlay
  const drawOnCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const chart = chartRef.current;
    const series = mainSeriesRef.current;
    
    if (!canvas || !chart || !series) return;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const timeScale = chart.timeScale();
    const allDrawings = [...drawings, currentDrawing].filter(Boolean) as Drawing[];
    
    // Helper to draw handles/control points
    const drawHandle = (x: number, y: number, isActive: boolean = false) => {
      ctx.save();
      // Outer ring
      ctx.beginPath();
      ctx.arc(x, y, isActive ? 8 : 6, 0, Math.PI * 2);
      ctx.fillStyle = isActive ? "rgba(34, 197, 94, 0.3)" : "rgba(255, 255, 255, 0.2)";
      ctx.fill();
      // Inner circle
      ctx.beginPath();
      ctx.arc(x, y, isActive ? 5 : 4, 0, Math.PI * 2);
      ctx.fillStyle = isActive ? "#22c55e" : "#ffffff";
      ctx.fill();
      ctx.strokeStyle = isActive ? "#16a34a" : "rgba(0, 0, 0, 0.5)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();
    };
    
    allDrawings.forEach((drawing) => {
      if (!drawing.points || drawing.points.length === 0) return;
      
      const points = drawing.points.map((p) => ({
        x: timeScale.timeToCoordinate(p.time),
        y: series.priceToCoordinate(p.price),
      }));
      
      // Filter out invalid coordinates
      if (points.some((p) => p.x === null || p.y === null)) return;
      
      const isSelected = drawing.id === selectedDrawingId;
      const isCurrentlyDrawing = drawing.id?.startsWith("drawing-") && currentDrawing?.id === drawing.id;
      const baseLineWidth = drawing.lineWidth || 2;
      
      // Set up drawing styles - thicker lines for better visibility
      ctx.strokeStyle = drawing.color;
      ctx.lineWidth = isSelected ? baseLineWidth + 2 : baseLineWidth + 1;
      ctx.fillStyle = drawing.color;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.setLineDash([]);
      
      switch (drawing.type) {
        case "trendline":
          if (points.length >= 2) {
            // Draw glow effect for visibility
            ctx.save();
            ctx.shadowColor = drawing.color;
            ctx.shadowBlur = isSelected ? 8 : 4;
            ctx.beginPath();
            ctx.moveTo(points[0].x!, points[0].y!);
            ctx.lineTo(points[1].x!, points[1].y!);
            ctx.stroke();
            ctx.restore();
            
            // Draw main line
            ctx.beginPath();
            ctx.moveTo(points[0].x!, points[0].y!);
            ctx.lineTo(points[1].x!, points[1].y!);
            ctx.stroke();
            
            // Always draw handles for better visibility
            points.forEach((p) => {
              drawHandle(p.x!, p.y!, isSelected || isCurrentlyDrawing);
            });
          }
          break;
          
        case "horizontal":
          if (points.length >= 1) {
            const y = points[0].y!;
            
            // Draw glow effect
            ctx.save();
            ctx.shadowColor = drawing.color;
            ctx.shadowBlur = isSelected ? 6 : 3;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
            ctx.restore();
            
            // Draw main line
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
            
            // Price label with better styling
            ctx.save();
            ctx.font = "bold 12px Inter, sans-serif";
            const priceText = `$${drawing.points[0].price.toFixed(2)}`;
            const textWidth = ctx.measureText(priceText).width;
            const labelX = canvas.width - textWidth - 16;
            const labelY = y;
            
            // Label background
            ctx.fillStyle = drawing.color;
            ctx.beginPath();
            ctx.roundRect(labelX - 4, labelY - 10, textWidth + 12, 20, 4);
            ctx.fill();
            
            // Label text
            ctx.fillStyle = "#000000";
            ctx.fillText(priceText, labelX + 2, labelY + 4);
            ctx.restore();
            
            // Draw handle on left
            drawHandle(40, y, isSelected || isCurrentlyDrawing);
          }
          break;
          
        case "fibonacci":
          if (points.length >= 2 && drawing.fibLevels) {
            const startY = points[0].y!;
            const endY = points[1].y!;
            const range = endY - startY;
            
            // Draw fib levels
            drawing.fibLevels.forEach((level, index) => {
              const y = startY + range * (1 - level);
              const alpha = index === 0 || index === drawing.fibLevels!.length - 1 ? 1 : 0.7;
              
              ctx.save();
              ctx.globalAlpha = alpha;
              ctx.lineWidth = level === 0.5 || level === 0.618 ? 2.5 : 1.5;
              ctx.beginPath();
              ctx.moveTo(points[0].x!, y);
              ctx.lineTo(canvas.width - 60, y);
              ctx.stroke();
              
              // Level label with background
              ctx.font = "bold 11px Inter, sans-serif";
              const levelText = `${(level * 100).toFixed(1)}%`;
              const textWidth = ctx.measureText(levelText).width;
              
              // Background
              ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
              ctx.fillRect(8, y - 8, textWidth + 8, 16);
              
              // Text
              ctx.fillStyle = drawing.color;
              ctx.fillText(levelText, 12, y + 4);
              ctx.restore();
            });
            
            // Connecting line
            ctx.save();
            ctx.setLineDash([6, 4]);
            ctx.lineWidth = 2;
            ctx.shadowColor = drawing.color;
            ctx.shadowBlur = 4;
            ctx.beginPath();
            ctx.moveTo(points[0].x!, points[0].y!);
            ctx.lineTo(points[1].x!, points[1].y!);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.restore();
            
            // Draw handles
            points.forEach((p) => {
              drawHandle(p.x!, p.y!, isSelected || isCurrentlyDrawing);
            });
          }
          break;
          
        case "channel":
          if (points.length >= 2) {
            // Draw main trendline with glow
            ctx.save();
            ctx.shadowColor = drawing.color;
            ctx.shadowBlur = isSelected ? 6 : 3;
            ctx.beginPath();
            ctx.moveTo(points[0].x!, points[0].y!);
            ctx.lineTo(points[1].x!, points[1].y!);
            ctx.stroke();
            ctx.restore();
            
            // Draw main line
            ctx.beginPath();
            ctx.moveTo(points[0].x!, points[0].y!);
            ctx.lineTo(points[1].x!, points[1].y!);
            ctx.stroke();
            
            // Draw parallel line
            if (points.length >= 3) {
              const offsetY = points[2].y! - points[0].y!;
              
              ctx.beginPath();
              ctx.moveTo(points[0].x!, points[0].y! + offsetY);
              ctx.lineTo(points[1].x!, points[1].y! + offsetY);
              ctx.stroke();
              
              // Fill channel with gradient-like effect
              ctx.save();
              ctx.globalAlpha = 0.15;
              ctx.beginPath();
              ctx.moveTo(points[0].x!, points[0].y!);
              ctx.lineTo(points[1].x!, points[1].y!);
              ctx.lineTo(points[1].x!, points[1].y! + offsetY);
              ctx.lineTo(points[0].x!, points[0].y! + offsetY);
              ctx.closePath();
              ctx.fill();
              ctx.restore();
              
              // Draw handle for parallel line
              drawHandle(points[0].x!, points[0].y! + offsetY, isSelected || isCurrentlyDrawing);
            }
            
            // Draw handles for main points
            points.slice(0, 2).forEach((p) => {
              drawHandle(p.x!, p.y!, isSelected || isCurrentlyDrawing);
            });
          }
          break;
      }
    });
  }, [drawings, currentDrawing, selectedDrawingId]);

  const getResponsiveHeight = useCallback(() => {
    if (fullscreen) return window.innerHeight;
    if (window.innerWidth < 640) return 500;
    if (window.innerWidth < 1024) return 600;
    return 700;
  }, [fullscreen]);

  // Setup chart (once per fullscreen state change)
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: getResponsiveHeight(),
      layout: {
        background: { color: "hsl(220, 20%, 10%)" },
        textColor: "hsl(210, 40%, 98%)",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
        fontSize: 12,
      },
      watermark: {
        visible: true,
        fontSize: 18,
        horzAlign: "left",
        vertAlign: "bottom",
        color: "rgba(255,255,255,0.04)",
        text: "Chart Buddy • TradingView-style",
      },
      grid: {
        vertLines: { color: "hsl(220, 18%, 16%)", style: 1 },
        horzLines: { color: "hsl(220, 18%, 16%)", style: 1 },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: "hsl(180, 85%, 60%)",
          width: 1,
          style: 2,
          labelBackgroundColor: "hsl(180, 85%, 35%)",
        },
        horzLine: {
          color: "hsl(180, 85%, 60%)",
          width: 1,
          style: 2,
          labelBackgroundColor: "hsl(180, 85%, 35%)",
        },
      },
      rightPriceScale: {
        borderColor: "hsl(220, 18%, 20%)",
        scaleMargins: { top: 0.08, bottom: 0.18 },
        autoScale: true,
        alignLabels: true,
      },
      timeScale: {
        borderColor: "hsl(220, 18%, 20%)",
        timeVisible: true,
        secondsVisible: false,
        barSpacing: 12,
        minBarSpacing: 6,
        rightOffset: 6,
        shiftVisibleRangeOnNewBar: true,
      },
      handleScale: {
        axisPressedMouseMove: { time: true, price: true },
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: true,
      },
    });

    chartRef.current = chart;

    // Mouse events for drawings
    chart.subscribeClick((param) => {
      if (!activeDrawingToolRef.current) {
        onDrawingSelectRef.current?.(null);
        return;
      }

      const point = getChartPoint(param);
      if (!point) return;

      if (!isDrawingRef.current) {
        onDrawingStartRef.current(point);
      } else {
        onDrawingEndRef.current();
      }
    });

    chart.subscribeCrosshairMove((param) => {
      if (isDrawingRef.current && activeDrawingToolRef.current) {
        const point = getChartPoint(param);
        if (point) {
          onDrawingUpdateRef.current(point);
        }
      }
    });

    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current && canvasRef.current) {
        const width = chartContainerRef.current.clientWidth;
        const height = getResponsiveHeight();
        chartRef.current.applyOptions({ width, height });
        canvasRef.current.width = width;
        canvasRef.current.height = height;
        drawOnCanvas();
      }
    };

    window.addEventListener("resize", handleResize);

    if (canvasRef.current && chartContainerRef.current) {
      canvasRef.current.width = chartContainerRef.current.clientWidth;
      canvasRef.current.height = getResponsiveHeight();
    }

    return () => {
      window.removeEventListener("resize", handleResize);
      priceLineRef.current = null;
      mainSeriesRef.current = null;
      hasFittedOnceRef.current = false;
      chart.remove();
    };
  }, [drawOnCanvas, fullscreen, getResponsiveHeight, getChartPoint]);

  // Upsert series and data (TradingView-like logic: keep zoom/scroll)
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart || data.length === 0) return;

    // Helper to clean price line
    const setPriceLine = (series: ISeriesApi<any>, price: number) => {
      if (priceLineRef.current && "remove" in priceLineRef.current) {
        priceLineRef.current.remove();
      }
      const lineOptions: PriceLineOptions = {
        price,
        color: "#22c55e",
        lineWidth: 2,
        lineStyle: 0,
        axisLabelVisible: true,
        title: "Last",
      };
      priceLineRef.current = series.createPriceLine(lineOptions);
    };

    // Main price series
    const createMainSeries = () => {
      if (mainSeriesRef.current && mainSeriesTypeRef.current !== chartType) {
        chart.removeSeries(mainSeriesRef.current);
        mainSeriesRef.current = null;
      }

      if (!mainSeriesRef.current) {
        if (chartType === "candlestick") {
          mainSeriesRef.current = chart.addSeries(CandlestickSeries, {
            upColor: "#22c55e",
            downColor: "#ef4444",
            borderVisible: true,
            borderUpColor: "#16a34a",
            borderDownColor: "#dc2626",
            wickUpColor: "#22c55e",
            wickDownColor: "#ef4444",
            priceLineVisible: false,
            lastValueVisible: false,
          });
          mainSeriesRef.current.priceScale().applyOptions({
            scaleMargins: { top: 0.05, bottom: 0.15 },
          });
          mainSeriesTypeRef.current = "candlestick";
        } else {
          mainSeriesRef.current = chart.addSeries(LineSeries, {
            color: "hsl(180, 85%, 55%)",
            lineWidth: 2,
            crosshairMarkerVisible: true,
            crosshairMarkerRadius: 4,
            priceLineVisible: false,
            lastValueVisible: false,
          });
          mainSeriesRef.current.priceScale().applyOptions({
            scaleMargins: { top: 0.05, bottom: 0.15 },
          });
          mainSeriesTypeRef.current = "line";
        }
      }

      if (mainSeriesTypeRef.current === "candlestick") {
        mainSeriesRef.current?.setData(data);
      } else {
        mainSeriesRef.current?.setData(data.map((d) => ({ time: d.time, value: d.close })));
      }

      const last = data[data.length - 1];
      if (last?.close) {
        setPriceLine(mainSeriesRef.current!, last.close);
      }
    };

    // Volume histogram
    const upsertVolume = () => {
      if (!showVolume || !volumeData || volumeData.length === 0) {
        if (volumeSeriesRef.current) {
          chart.removeSeries(volumeSeriesRef.current);
          volumeSeriesRef.current = null;
        }
        return;
      }

      if (!volumeSeriesRef.current) {
        volumeSeriesRef.current = chart.addSeries(HistogramSeries, {
          color: "hsl(180, 85%, 55%)",
          priceFormat: { type: "volume" },
          priceScaleId: "",
        });
        volumeSeriesRef.current.priceScale().applyOptions({
          scaleMargins: { top: 0.8, bottom: 0 },
        });
      }
      volumeSeriesRef.current.setData(volumeData);
    };

    // Bollinger bands
    const upsertBollinger = () => {
      if (!bollingerData) {
        Object.values(bollingerSeriesRef.current).forEach((s) => s && chart.removeSeries(s));
        bollingerSeriesRef.current = { upper: undefined, middle: undefined, lower: undefined };
        return;
      }

      const ensure = (
        key: keyof typeof bollingerSeriesRef.current,
        options: SeriesOptionsMap["Line"]
      ) => {
        if (!bollingerSeriesRef.current[key]) {
          bollingerSeriesRef.current[key] = chart.addSeries(LineSeries, options);
        }
        return bollingerSeriesRef.current[key]!;
      };

      ensure("upper", { color: "hsl(180, 85%, 55%)", lineWidth: 1, lineStyle: 2 }).setData(
        bollingerData.upper.filter((d) => !isNaN(d.value))
      );
      ensure("middle", { color: "hsl(180, 85%, 55%)", lineWidth: 1 }).setData(
        bollingerData.middle.filter((d) => !isNaN(d.value))
      );
      ensure("lower", { color: "hsl(180, 85%, 55%)", lineWidth: 1, lineStyle: 2 }).setData(
        bollingerData.lower.filter((d) => !isNaN(d.value))
      );
    };

    // RSI
    const upsertRSI = () => {
      if (!rsiData) {
        if (rsiSeriesRef.current) {
          chart.removeSeries(rsiSeriesRef.current);
          rsiSeriesRef.current = null;
        }
        return;
      }
      if (!rsiSeriesRef.current) {
        rsiSeriesRef.current = chart.addSeries(LineSeries, {
          color: "hsl(270, 70%, 60%)",
          lineWidth: 2,
          priceScaleId: "rsi",
        });
        rsiSeriesRef.current.priceScale().applyOptions({
          scaleMargins: { top: 0.85, bottom: 0 },
        });
      }
      rsiSeriesRef.current.setData(rsiData.filter((d) => !isNaN(d.value)));
    };

    // MACD
    const upsertMACD = () => {
      const refs = macdSeriesRef.current;
      if (!macdData) {
        ["macd", "signal", "histogram"].forEach((key) => {
          const s = (refs as any)[key];
          if (s) chart.removeSeries(s);
        });
        macdSeriesRef.current = { macd: undefined, signal: undefined, histogram: undefined };
        return;
      }

      if (!refs.macd) {
        refs.macd = chart.addSeries(LineSeries, {
          color: "hsl(200, 70%, 60%)",
          lineWidth: 2,
          priceScaleId: "macd",
        });
        refs.macd.priceScale().applyOptions({ scaleMargins: { top: 0.9, bottom: 0 } });
      }
      refs.macd.setData(macdData.macd.filter((d) => !isNaN(d.value)));

      if (!refs.signal) {
        refs.signal = chart.addSeries(LineSeries, {
          color: "hsl(30, 70%, 60%)",
          lineWidth: 2,
          priceScaleId: "macd",
        });
      }
      refs.signal.setData(macdData.signal.filter((d) => !isNaN(d.value)));

      if (!refs.histogram) {
        refs.histogram = chart.addSeries(HistogramSeries, { priceScaleId: "macd" });
      }
      refs.histogram.setData(macdData.histogram.filter((d) => !isNaN(d.value)));
    };

    createMainSeries();
    upsertVolume();
    upsertBollinger();
    upsertRSI();
    upsertMACD();

    if (!hasFittedOnceRef.current) {
      chart.timeScale().fitContent();
      hasFittedOnceRef.current = true;
    }
    drawOnCanvas();
  }, [chartType, data, volumeData, showVolume, rsiData, macdData, bollingerData, drawOnCanvas]);

  // Redraw canvas when drawings change
  useEffect(() => {
    drawOnCanvas();
  }, [drawOnCanvas]);

  // Subscribe to chart updates for canvas sync
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    
    const handleTimeRangeChange = () => {
      drawOnCanvas();
    };
    
    chart.timeScale().subscribeVisibleTimeRangeChange(handleTimeRangeChange);
    
    return () => {
      chart.timeScale().unsubscribeVisibleTimeRangeChange(handleTimeRangeChange);
    };
  }, [drawOnCanvas]);

  return (
    <div className="relative w-full">
      <div ref={chartContainerRef} className="w-full" />
      <canvas
        ref={canvasRef}
        className="absolute top-0 left-0 pointer-events-none"
        style={{ width: "100%", height: "100%" }}
      />
      {activeDrawingTool && (
        <div className="absolute top-3 left-3 bg-success text-success-foreground text-sm font-medium px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 animate-pulse">
          <span className="w-2 h-2 bg-white rounded-full" />
          Drawing: {activeDrawingTool} • Click to place first point, click again to finish
        </div>
      )}
    </div>
  );
};
